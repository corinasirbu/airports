INSERT INTO public.airlines (active,alias,callsign,country,iata,icao,name) VALUES
	 (false,'','AEGEAN','Greece','A3','AEE','Aegean Airlines'),
	 (false,'','AEROFLOT','Russia','SU','AFL','Aeroflot Russian Airlines'),
	 (false,'','AIRFRANS','France','AF','AFR','Air France'),
	 (false,'','AIR BERLIN','Germany','AB','BER','Air Berlin'),
	 (false,'','AUSTRIAN','Austria','OS','AUA','Austrian Airlines'),
	 (false,'','AIR MOLDOVA','Moldova','9U','MLD','Air Moldova'),
	 (false,'','SPEEDBIRD','United Kingdom','BA','BAW','British Airways'),
	 (false,'','BLUE TRANSPORT','Romania','0B','JOR','Blue Air'),
	 (false,'','CARPATAIR','Romania','V3','KRP','Carpatair'),
	 (false,'CSA Czech Airlines','CSA-LINES','Czech Republic','OK','CSA','Czech Airlines');
INSERT INTO public.airlines (active,alias,callsign,country,iata,icao,name) VALUES
	 (false,'','ELAL','Israel','LY','ELY','El Al Israel Airlines'),
	 (false,'','EUROWINGS','Germany','EW','EWG','Eurowings'),
	 (false,'','KLM','Netherlands','KL','KLM','KLM Royal Dutch Airlines'),
	 (false,'','POLLOT','Poland','LO','LOT','LOT Polish Airlines'),
	 (false,'','LUFTHANSA','Germany','LH','DLH','Lufthansa'),
	 (false,'','SUNTURK','Turkey','PC','PGT','Pegasus Airlines'),
	 (false,'','QATARI','Qatar','QR','QTR','Qatar Airways'),
	 (false,'','RYANAIR','Ireland','FR','RYR','Ryanair'),
	 (false,'SAS Scandinavian Airlines','SCANDINAVIAN','Sweden','SK','SAS','Scandinavian Airlines System'),
	 (false,'Swiss Airlines','SWISS','Switzerland','LX','SWR','Swiss International Air Lines');
INSERT INTO public.airlines (active,alias,callsign,country,iata,icao,name) VALUES
	 (false,'TAP Air Portugal','AIR PORTUGAL','Portugal','TP','TAP','TAP Portugal'),
	 (false,'','TURKAIR','Turkey','TK','THY','Turkish Airlines'),
	 (false,'','TAROM','Romania','RO','ROT','Tarom'),
	 (false,'','VUELING','Spain','VY','VLG','Vueling Airlines'),
	 (false,'','WIZZ AIR','Hungary','W6','WZZ','Wizz Air'),
	 (false,'','','United Arab Emirates','FZ','FDB','Fly Dubai'),
	 (false,'','Smartwings','Romania','','SMW','Carpatair Flight Training'),
	 (false,'','','Romania','','BUR','Air Bucharest'),
	 (false,'','','Romania','','DSV','Direct Aero Services'),
	 (false,'','MEDALS','Romania','','MDP','Medallion Air');
INSERT INTO public.airlines (active,alias,callsign,country,iata,icao,name) VALUES
	 (false,'','AIR SERBIA','Serbia','JU','ASL','Air Serbia'),
	 (false,'','','Romania','','TNS','Transilvania'),
	 (false,'','TENDER AIR','Romania','X5','OTJ','Fly Romania');